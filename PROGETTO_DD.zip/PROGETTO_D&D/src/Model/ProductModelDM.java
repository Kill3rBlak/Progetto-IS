package Model;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.LinkedList;

import com.mysql.jdbc.PreparedStatement;

import ConnectionPool.ConnectionDatabase;

public class ProductModelDM implements ProductModel {
	
	private static final String TABLE_NAME = "articolo";
		
	@Override
	public void doSave(Articolo product) throws SQLException {
	}

	@Override
	public boolean doDelete(String code) throws SQLException {
		ConnectionDatabase connection=new ConnectionDatabase();
		PreparedStatement preparedStatement = null;
		int result=0;
		String deleteSQL=null;
		int n=code.length();
			code=code.substring(0, n-1);
			deleteSQL="DELETE FROM articolo WHERE codice=? ";
			connection.getConnection();		
			preparedStatement=connection.prepareStatement(deleteSQL);
			preparedStatement.setString(1, code);
			result = preparedStatement.executeUpdate();
	
		
		connection.close();
		return (result != 0);
	}		
	

	@Override
	public <T> T doRetrieveByKey(String code) throws SQLException {   //restituisce un oggetto in base all'id
		ConnectionDatabase connection=new ConnectionDatabase();
		PreparedStatement preparedStatement = null;		
		connection.getConnection();
		String selectSQL="";

		
			 selectSQL = "SELECT * FROM articolo  WHERE codice=?";
			 Articolo art=new Articolo();
			 preparedStatement=connection.prepareStatement(selectSQL);
			 preparedStatement.setString(1, code);
				ResultSet rs = preparedStatement.executeQuery();

				while(rs.next()){
					art.setCodice(rs.getString("codice"));
					art.setDescrizione(rs.getString("descrizione"));
					art.setPrezzo(rs.getDouble("prezzo"));
					art.setQuantità(rs.getInt("quantità"));
				
				return (T) art;
		}
		connection.close();
		
		return null;
	}

	
	@Override
	public <T> Collection<T> doRetrieveAll(String order) throws SQLException {  //restituisce elenco eventi,biglietto,abbigliamento,soci
		ConnectionDatabase connection=new ConnectionDatabase();
		PreparedStatement preparedStatement = null;		
		connection.getConnection();
		Collection<T> products = new LinkedList<T>();     //collezione di prodotti che possono essere eventi,biglietti o articoli
		String selectSQL="";
	
			 selectSQL = "SELECT * FROM articolo";
			 preparedStatement=connection.prepareStatement(selectSQL);
				ResultSet rs = preparedStatement.executeQuery();
				while(rs.next()){
					Articolo art=new Articolo();
					art.setCodice(rs.getString("codice"));
					art.setDescrizione(rs.getString("descrizione"));
					art.setPrezzo(rs.getDouble("prezzo"));
					art.setQuantità(rs.getInt("quantità"));
					products.add((T) art);
				
		}
	
		
		connection.close();
		return products;
	}

}
